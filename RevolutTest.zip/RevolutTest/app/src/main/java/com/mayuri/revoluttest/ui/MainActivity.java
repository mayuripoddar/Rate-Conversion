package com.mayuri.revoluttest.ui;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mayuri.revoluttest.Listeners.OnPositionClickListener;
import com.mayuri.revoluttest.MyApplication;
import com.mayuri.revoluttest.R;
import com.mayuri.revoluttest.Receiver.DownloadResultReceiver;
import com.mayuri.revoluttest.Receiver.DownloadService;
import com.mayuri.revoluttest.adaptor.RecyclerViewAdapter;

import com.mayuri.revoluttest.di.component.ApplicationComponent;
import com.mayuri.revoluttest.di.component.DaggerApplicationComponent;
import com.mayuri.revoluttest.di.component.DaggerMainActivityComponent;
import com.mayuri.revoluttest.di.component.MainActivityComponent;
import com.mayuri.revoluttest.di.module.ContextModule;
import com.mayuri.revoluttest.di.module.MainActivityContextModule;
import com.mayuri.revoluttest.di.qualifier.ActivityContext;
import com.mayuri.revoluttest.di.qualifier.ApplicationContext;
import com.mayuri.revoluttest.pojo.RatesData;
import com.mayuri.revoluttest.retrofit.APIInterface;
import com.mayuri.revoluttest.retrofit.Constans;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class MainActivity extends AppCompatActivity implements DownloadResultReceiver.Receiver, OnPositionClickListener, RecyclerViewAdapter.ClickListener {

    private RecyclerView recyclerView;
    MainActivityComponent mainActivityComponent;

    @Inject
    public RecyclerViewAdapter recyclerViewAdapter;

    @Inject
    public APIInterface apiInterface;

    @Inject
    @ApplicationContext
    public Context mContext;

    @Inject
    @ActivityContext
    public Context activityContext;

    private ListView listView = null;
    private ArrayList<RatesData> ratesData;
    private ArrayAdapter arrayAdapter = null;
    private RecyclerView listOfCurrencies;
    private DownloadResultReceiver mReceiver;
    RecyclerViewAdapter currenciesAdapter;
    private boolean isFirstCall, isFlag;
    private String TAG = "CL";
    private EditText editTextCurrValue;

    private TextView textViewCurrCountryName, textCurrIndicator;

    private ImageView imageViewCurrImage;

    private RatesData ratesDataSingleValue;

    private int dollarValue = 100;

    private String countryCodeForRemove;

    private Map<String, RatesData> hashMapRateData;

    private LinearLayout controlLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /* Allow activity to show indeterminate progressbar */
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        setContentView(R.layout.activity_main);



        /* Set activity layout */
        //    setContentView(R.layout.activity_main);

        /* Initialize activity layout views*/
        editTextCurrValue = findViewById(R.id.editTextCurrValue);
        textViewCurrCountryName = findViewById(R.id.textViewCurrCountryName);
        imageViewCurrImage = findViewById(R.id.imageViewCurrImage);
        textCurrIndicator = findViewById(R.id.textCurrIndicator);
        controlLayout = findViewById(R.id.controlLayout);
        controlLayout.setVisibility(View.GONE);

        /* Initialize RecyclerView */
        listOfCurrencies = (RecyclerView) findViewById(R.id.listOfCurrencies);
        //listOfCurrencies.setLayoutManager(new LinearLayoutManager(this));
        listOfCurrencies.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        listOfCurrencies.setLayoutManager(layoutManager);

        ApplicationComponent applicationComponent = DaggerApplicationComponent.builder().contextModule(new ContextModule(this)).build();
        applicationComponent.injectApplication(MyApplication.getInstance());

        ApplicationComponent applicationComponent1 = MyApplication.getInstance().getApplicationComponent();
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .mainActivityContextModule(new MainActivityContextModule(this))
                .applicationComponent(applicationComponent)
                .build();

        mainActivityComponent.injectMainActivity(this);


        currenciesAdapter = new RecyclerViewAdapter(this);
        listOfCurrencies.setAdapter(currenciesAdapter);

    }

    @Override
    public void launchIntent(String RepoName) {

        Log.e("EM", ":::::::::::Calling::::::::" + RepoName);

    }

    private class InitialSetData extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            /* Get Initial value from locally json data */
            ratesData = new ArrayList<>();
            ratesData = Constans.getInitialValue();
            return null;
        }

        @Override
        protected void onPostExecute(String result) {


            if (!isFirstCall) {
                setViewsValue(ratesData.get(0), Constans.fromData1);
                isFirstCall = true;
            }
            removeSelectedValue();
            /* Starting Download Service */
            mReceiver = new DownloadResultReceiver(new Handler());
            mReceiver.setReceiver(MainActivity.this);
            Intent intent = new Intent(Intent.ACTION_SYNC, null, MainActivity.this, DownloadService.class);

            /* Send optional extras to Download IntentService */
            intent.putExtra("url", Constans.url);
            intent.putExtra("receiver", mReceiver);
            intent.putExtra("requestId", 101);

            startService(intent);
        }

        @Override
        protected void onPreExecute() {


        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart: ");
    }

    @Override
    protected void onResume() {
        super.onResume();
        isFlag = true;
        Constans.serviceStopStauts = false;
        new InitialSetData().execute();
        Log.i(TAG, "onResume: ");

    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i(TAG, "onPause: ");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop: ");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart: ");
    }

    public void removeSelectedValue() {
        /* Prepare hash map data for RecyclerView */
        hashMapRateData = new HashMap<>();
        for (int i = 0; i < ratesData.size(); i++) {
            hashMapRateData.put(ratesData.get(i).getDataName(), ratesData.get(i));

        }
        /* Remove select country code from hash map */
        // hashMapRateData.remove(countryCodeForRemove);
        if (currenciesAdapter != null) {
            /* notifyDataSetChanged RecyclerView with result */
            ((RecyclerViewAdapter) currenciesAdapter).setData(hashMapRateData, dollarValue, MainActivity.this, MainActivity.this);
            currenciesAdapter.notifyDataSetChanged();
        }


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Constans.serviceStopStauts = true;
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
//        ActivityManager am = (ActivityManager) this.getSystemService(Activity.ACTIVITY_SERVICE);
//        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(3); //3 because we have to give it something. This is an arbitrary number
//        int activityCount = tasks.get(0).numActivities;
//
//        if (activityCount < 3) {
//            moveTaskToBack(true);
//        } else {
//            super.onBackPressed();
//        }
    }

    public void setViewsValue(RatesData ratesDataSingleValue, int fromWhichData) {
        controlLayout.setVisibility(View.VISIBLE);
        this.ratesDataSingleValue = ratesDataSingleValue;


        /* Set Data Accourding to Requirement */
        if (fromWhichData == Constans.fromData1) {
            editTextCurrValue.setText("" + dollarValue);
            textCurrIndicator.setText(Constans.baseDollorName);
            textViewCurrCountryName.setText(Constans.baseName);
            countryCodeForRemove = Constans.countryBaseCode;

        } else {
            Constans.countryBaseCode = ratesDataSingleValue.getDataName();
            editTextCurrValue.setText(String.format("%.2f", ratesDataSingleValue.getDataValue()));
            textCurrIndicator.setText(ratesDataSingleValue.getDollorName());
            textViewCurrCountryName.setText(ratesDataSingleValue.getDataName());
            countryCodeForRemove = ratesDataSingleValue.getDataName();
        }
        /* Load image from Picasso */
        Picasso.with(this).load(Constans.getResourceIds(Constans.countryBaseCode.toLowerCase(), this)).placeholder(R.drawable.ic_circle).into(imageViewCurrImage);

    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case DownloadService.STATUS_RUNNING:

                setProgressBarIndeterminateVisibility(true);
                break;
            case DownloadService.STATUS_FINISHED:
                /* Hide progress & extract result from bundle */
                setProgressBarIndeterminateVisibility(false);
                ratesData = new ArrayList<>();
                ratesData = (ArrayList<RatesData>) resultData.getSerializable("result");

                if (ratesData != null && ratesData.size() > 0) {


                    removeSelectedValue();


                }

                break;
            case DownloadService.STATUS_ERROR:
                /* Handle the error */
                String error = resultData.getString(Intent.EXTRA_TEXT);
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                break;
        }
    }


    /* On item click  onPostionClick method will call*/
    @Override
    public void onPostionClick(RatesData ratesDataSingleValue) {
        setViewsValue(ratesDataSingleValue, Constans.fromData2);
    }


}

