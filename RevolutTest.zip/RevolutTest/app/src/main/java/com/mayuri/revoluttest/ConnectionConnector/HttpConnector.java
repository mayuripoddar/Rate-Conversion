package com.mayuri.revoluttest.ConnectionConnector;

import android.content.Context;
import android.util.Log;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class HttpConnector {
    private static String url_param;
    private static HttpURLConnection conn;
    private static final String TAG = "CL";

    public HttpConnector(String url_param) {
        this.url_param = url_param;
    }

    public static String fetchData(Context cn) {
        InputStream is = null;
        InputStreamReader isr = null;
        StringBuffer sb = null; // To read data
        Log.d(TAG, "The url is: " + url_param);

        try {
            URL url = new URL(url_param);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(40000  /* milliseconds */);
            conn.setConnectTimeout(40000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");

            conn.setRequestProperty("charset", "utf-8");
            // Starts the query
            conn.connect();
            int response_code = conn.getResponseCode();
            Log.e(TAG, "get data::::::" + response_code);
            // Read data from network
            if (response_code == HttpURLConnection.HTTP_OK) {
                is = conn.getInputStream();
                // Add is to Reader for buffered data reading from server
                isr = new InputStreamReader(is);
                sb = new StringBuffer();
                char[] readBuffer = new char[1024];
                int count = 0;
                while ((count = isr.read(readBuffer)) != -1) {
                    sb.append(readBuffer, 0, count);
                }
                return sb.toString();
            } else {
                throw new Exception();
            }

            // Makes sure that the InputStream is closed after the app is
            // finished using it.
        } catch (Exception e) {
            return null;
        } finally {
            // Close inner stream.
            if (is != null) {
                try {
                    conn.disconnect();
                    is.close();
                } catch (Exception e) {
                    // TODO: handle exception
                }
            }

            if (isr != null) {
                try {
                    isr.close();
                } catch (Exception e) {

                }
            }
            sb = null;
        }
    }

}
