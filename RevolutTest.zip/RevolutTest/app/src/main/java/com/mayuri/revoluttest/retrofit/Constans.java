package com.mayuri.revoluttest.retrofit;

import android.content.Context;


import com.mayuri.revoluttest.pojo.RatesData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Constans {
    public static String countryBaseCode = "EUR";

    public static String url = "https://revolut.duckdns.org/latest?base=";
    public static int fromData1 = 0;
    public static int fromData2 = 1;
    public static String baseName = "";
    public static String baseDollorName = "";
    public static boolean serviceStopStauts;
    private static String inData = "{\"base\":\"EUR\",\"date\":\"2018-09-06\",\"rates\":{\"AUD\":1.6224,\"BGN\":1.9631,\"BRL\":4.8097,\"CAD\":1.5395,\"CHF\":1.1317,\"CNY\":7.9747,\"CZK\":25.811,\"DKK\":7.4845,\"GBP\":0.90159,\"HKD\":9.1664,\"HRK\":7.4618,\"HUF\":327.71,\"IDR\":17388.0,\"ILS\":4.1861,\"INR\":84.029,\"ISK\":128.28,\"JPY\":130.03,\"KRW\":1309.6,\"MXN\":22.449,\"MYR\":4.8299,\"NOK\":9.8124,\"NZD\":1.7699,\"PHP\":62.825,\"PLN\":4.3344,\"RON\":4.6558,\"RUB\":79.871,\"SEK\":10.63,\"SGD\":1.606,\"THB\":38.272,\"TRY\":7.6566,\"USD\":1.1677,\"ZAR\":17.89}}";

    public static int getResourceIds(String resourceName, Context mContext) {
        int resId = getResourceId(resourceName, "drawable", mContext.getPackageName(), mContext);
        return resId;
    }

    public static int getResourceId(String pVariableName, String pResourcename, String pPackageName, Context mContext) {
        try {
            return mContext.getResources().getIdentifier(pVariableName, pResourcename, pPackageName);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static Map<String, String> getCountryDollor() {
        Map<String, String> stringStringMap = new HashMap<>();
        String dataVal = "[\n" +
                "  {\n" +
                "    \"Dname\": \"Afghani\",\n" +
                "    \"Dcode\": \"AFN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lek\",\n" +
                "    \"Dcode\": \"ALL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Algerian Dinar\",\n" +
                "    \"Dcode\": \"DZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kwanza\",\n" +
                "    \"Dcode\": \"AOA\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Argentine Peso\",\n" +
                "    \"Dcode\": \"ARS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Armenian Dram\",\n" +
                "    \"Dcode\": \"AMD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Aruban Florin\",\n" +
                "    \"Dcode\": \"AWG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Azerbaijan Manat\",\n" +
                "    \"Dcode\": \"AZN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Bahamian Dollar\",\n" +
                "    \"Dcode\": \"BSD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Bahraini Dinar\",\n" +
                "    \"Dcode\": \"BHD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Taka\",\n" +
                "    \"Dcode\": \"BDT\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Barbados Dollar\",\n" +
                "    \"Dcode\": \"BBD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Belarusian Ruble\",\n" +
                "    \"Dcode\": \"BYN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Belize Dollar\",\n" +
                "    \"Dcode\": \"BZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Bermudian Dollar\",\n" +
                "    \"Dcode\": \"BMD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Indian Rupee\",\n" +
                "    \"Dcode\": \"INR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Ngultrum\",\n" +
                "    \"Dcode\": \"BTN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Boliviano\",\n" +
                "    \"Dcode\": \"BOB\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Mvdol\",\n" +
                "    \"Dcode\": \"BOV\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Convertible Mark\",\n" +
                "    \"Dcode\": \"BAM\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pula\",\n" +
                "    \"Dcode\": \"BWP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Norwegian Krone\",\n" +
                "    \"Dcode\": \"NOK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Brazilian Real\",\n" +
                "    \"Dcode\": \"BRL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Brunei Dollar\",\n" +
                "    \"Dcode\": \"BND\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Bulgarian Lev\",\n" +
                "    \"Dcode\": \"BGN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Burundi Franc\",\n" +
                "    \"Dcode\": \"BIF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Cabo Verde Escudo\",\n" +
                "    \"Dcode\": \"CVE\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Riel\",\n" +
                "    \"Dcode\": \"KHR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Canadian Dollar\",\n" +
                "    \"Dcode\": \"CAD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Cayman Islands Dollar\",\n" +
                "    \"Dcode\": \"KYD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Chilean Peso\",\n" +
                "    \"Dcode\": \"CLP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Unidad de Fomento\",\n" +
                "    \"Dcode\": \"CLF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Yuan Renminbi\",\n" +
                "    \"Dcode\": \"CNY\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Colombian Peso\",\n" +
                "    \"Dcode\": \"COP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Unidad de Valor Real\",\n" +
                "    \"Dcode\": \"COU\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Comorian Franc \",\n" +
                "    \"Dcode\": \"KMF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Congolese Franc\",\n" +
                "    \"Dcode\": \"CDF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Zealand Dollar\",\n" +
                "    \"Dcode\": \"NZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Costa Rican Colon\",\n" +
                "    \"Dcode\": \"CRC\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kuna\",\n" +
                "    \"Dcode\": \"HRK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Cuban Peso\",\n" +
                "    \"Dcode\": \"CUP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Peso Convertible\",\n" +
                "    \"Dcode\": \"CUC\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Netherlands Antillean Guilder\",\n" +
                "    \"Dcode\": \"ANG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Czech Koruna\",\n" +
                "    \"Dcode\": \"CZK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Danish Krone\",\n" +
                "    \"Dcode\": \"DKK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Djibouti Franc\",\n" +
                "    \"Dcode\": \"DJF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Dominican Peso\",\n" +
                "    \"Dcode\": \"DOP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Egyptian Pound\",\n" +
                "    \"Dcode\": \"EGP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"El Salvador Colon\",\n" +
                "    \"Dcode\": \"SVC\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Nakfa\",\n" +
                "    \"Dcode\": \"ERN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Ethiopian Birr\",\n" +
                "    \"Dcode\": \"ETB\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Falkland Islands Pound\",\n" +
                "    \"Dcode\": \"FKP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Danish Krone\",\n" +
                "    \"Dcode\": \"DKK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Fiji Dollar\",\n" +
                "    \"Dcode\": \"FJD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFP Franc\",\n" +
                "    \"Dcode\": \"XPF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BEAC\",\n" +
                "    \"Dcode\": \"XAF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Dalasi\",\n" +
                "    \"Dcode\": \"GMD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lari\",\n" +
                "    \"Dcode\": \"GEL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Ghana Cedi\",\n" +
                "    \"Dcode\": \"GHS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Gibraltar Pound\",\n" +
                "    \"Dcode\": \"GIP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Danish Krone\",\n" +
                "    \"Dcode\": \"DKK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Quetzal\",\n" +
                "    \"Dcode\": \"GTQ\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pound Sterling\",\n" +
                "    \"Dcode\": \"GBP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Guinean Franc\",\n" +
                "    \"Dcode\": \"GNF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Guyana Dollar\",\n" +
                "    \"Dcode\": \"GYD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Gourde\",\n" +
                "    \"Dcode\": \"HTG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lempira\",\n" +
                "    \"Dcode\": \"HNL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Hong Kong Dollar\",\n" +
                "    \"Dcode\": \"HKD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Forint\",\n" +
                "    \"Dcode\": \"HUF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Iceland Krona\",\n" +
                "    \"Dcode\": \"ISK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Indian Rupee\",\n" +
                "    \"Dcode\": \"INR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rupiah\",\n" +
                "    \"Dcode\": \"IDR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"SDR (Special Drawing Right)\",\n" +
                "    \"Dcode\": \"XDR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Iranian Rial\",\n" +
                "    \"Dcode\": \"IRR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Iraqi Dinar\",\n" +
                "    \"Dcode\": \"IQD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pound Sterling\",\n" +
                "    \"Dcode\": \"GBP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Israeli Sheqel\",\n" +
                "    \"Dcode\": \"ILS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Jamaican Dollar\",\n" +
                "    \"Dcode\": \"JMD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Yen\",\n" +
                "    \"Dcode\": \"JPY\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pound Sterling\",\n" +
                "    \"Dcode\": \"GBP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Jordanian Dinar\",\n" +
                "    \"Dcode\": \"JOD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Tenge\",\n" +
                "    \"Dcode\": \"KZT\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kenyan Shilling\",\n" +
                "    \"Dcode\": \"KES\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"North Korean Won\",\n" +
                "    \"Dcode\": \"KPW\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Won\",\n" +
                "    \"Dcode\": \"KRW\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kuwaiti Dinar\",\n" +
                "    \"Dcode\": \"KWD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Som\",\n" +
                "    \"Dcode\": \"KGS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lao Kip\",\n" +
                "    \"Dcode\": \"LAK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lebanese Pound\",\n" +
                "    \"Dcode\": \"LBP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Loti\",\n" +
                "    \"Dcode\": \"LSL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rand\",\n" +
                "    \"Dcode\": \"ZAR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Liberian Dollar\",\n" +
                "    \"Dcode\": \"LRD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Libyan Dinar\",\n" +
                "    \"Dcode\": \"LYD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Swiss Franc\",\n" +
                "    \"Dcode\": \"CHF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pataca\",\n" +
                "    \"Dcode\": \"MOP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Denar\",\n" +
                "    \"Dcode\": \"MKD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Malagasy Ariary\",\n" +
                "    \"Dcode\": \"MGA\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Malawi Kwacha\",\n" +
                "    \"Dcode\": \"MWK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Malaysian Ringgit\",\n" +
                "    \"Dcode\": \"MYR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rufiyaa\",\n" +
                "    \"Dcode\": \"MVR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Ouguiya\",\n" +
                "    \"Dcode\": \"MRU\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Mauritius Rupee\",\n" +
                "    \"Dcode\": \"MUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"ADB Unit of Account\",\n" +
                "    \"Dcode\": \"XUA\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Mexican Peso\",\n" +
                "    \"Dcode\": \"MXN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Mexican Unidad de Inversion (UDI)\",\n" +
                "    \"Dcode\": \"MXV\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Moldovan Leu\",\n" +
                "    \"Dcode\": \"MDL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Tugrik\",\n" +
                "    \"Dcode\": \"MNT\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Moroccan Dirham\",\n" +
                "    \"Dcode\": \"MAD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Mozambique Metical\",\n" +
                "    \"Dcode\": \"MZN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kyat\",\n" +
                "    \"Dcode\": \"MMK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Namibia Dollar\",\n" +
                "    \"Dcode\": \"NAD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rand\",\n" +
                "    \"Dcode\": \"ZAR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Nepalese Rupee\",\n" +
                "    \"Dcode\": \"NPR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFP Franc\",\n" +
                "    \"Dcode\": \"XPF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Zealand Dollar\",\n" +
                "    \"Dcode\": \"NZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Cordoba Oro\",\n" +
                "    \"Dcode\": \"NIO\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Naira\",\n" +
                "    \"Dcode\": \"NGN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Zealand Dollar\",\n" +
                "    \"Dcode\": \"NZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Norwegian Krone\",\n" +
                "    \"Dcode\": \"NOK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rial Omani\",\n" +
                "    \"Dcode\": \"OMR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pakistan Rupee\",\n" +
                "    \"Dcode\": \"PKR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +

                "  {\n" +
                "    \"Dname\": \"Balboa\",\n" +
                "    \"Dcode\": \"PAB\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Kina\",\n" +
                "    \"Dcode\": \"PGK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Guarani\",\n" +
                "    \"Dcode\": \"PYG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Sol\",\n" +
                "    \"Dcode\": \"PEN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Philippine Peso\",\n" +
                "    \"Dcode\": \"PHP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Zealand Dollar\",\n" +
                "    \"Dcode\": \"NZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Zloty\",\n" +
                "    \"Dcode\": \"PLN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Qatari Rial\",\n" +
                "    \"Dcode\": \"QAR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Romanian Leu\",\n" +
                "    \"Dcode\": \"RON\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Russian Ruble\",\n" +
                "    \"Dcode\": \"RUB\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rwanda Franc\",\n" +
                "    \"Dcode\": \"RWF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Saint Helena Pound\",\n" +
                "    \"Dcode\": \"SHP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"East Caribbean Dollar\",\n" +
                "    \"Dcode\": \"XCD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Tala\",\n" +
                "    \"Dcode\": \"WST\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Dobra\",\n" +
                "    \"Dcode\": \"STN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Saudi Riyal\",\n" +
                "    \"Dcode\": \"SAR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Serbian Dinar\",\n" +
                "    \"Dcode\": \"RSD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Seychelles Rupee\",\n" +
                "    \"Dcode\": \"SCR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Leone\",\n" +
                "    \"Dcode\": \"SLL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Singapore Dollar\",\n" +
                "    \"Dcode\": \"SGD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Netherlands Antillean Guilder\",\n" +
                "    \"Dcode\": \"ANG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Sucre\",\n" +
                "    \"Dcode\": \"XSU\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Solomon Islands Dollar\",\n" +
                "    \"Dcode\": \"SBD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Somali Shilling\",\n" +
                "    \"Dcode\": \"SOS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Rand\",\n" +
                "    \"Dcode\": \"ZAR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"No universal currency\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"South Sudanese Pound\",\n" +
                "    \"Dcode\": \"SSP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Euro\",\n" +
                "    \"Dcode\": \"EUR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Sri Lanka Rupee\",\n" +
                "    \"Dcode\": \"LKR\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Sudanese Pound\",\n" +
                "    \"Dcode\": \"SDG\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Surinam Dollar\",\n" +
                "    \"Dcode\": \"SRD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Norwegian Krone\",\n" +
                "    \"Dcode\": \"NOK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Lilangeni\",\n" +
                "    \"Dcode\": \"SZL\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Swedish Krona\",\n" +
                "    \"Dcode\": \"SEK\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Swiss Franc\",\n" +
                "    \"Dcode\": \"CHF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"WIR Euro\",\n" +
                "    \"Dcode\": \"CHE\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"WIR Franc\",\n" +
                "    \"Dcode\": \"CHW\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Syrian Pound\",\n" +
                "    \"Dcode\": \"SYP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Taiwan Dollar\",\n" +
                "    \"Dcode\": \"TWD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Somoni\",\n" +
                "    \"Dcode\": \"TJS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Tanzanian Shilling\",\n" +
                "    \"Dcode\": \"TZS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Baht\",\n" +
                "    \"Dcode\": \"THB\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFA Franc BCEAO\",\n" +
                "    \"Dcode\": \"XOF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"New Zealand Dollar\",\n" +
                "    \"Dcode\": \"NZD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pa’anga\",\n" +
                "    \"Dcode\": \"TOP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Trinidad and Tobago Dollar\",\n" +
                "    \"Dcode\": \"TTD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Tunisian Dinar\",\n" +
                "    \"Dcode\": \"TND\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Turkish Lira\",\n" +
                "    \"Dcode\": \"TRY\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Turkmenistan New Manat\",\n" +
                "    \"Dcode\": \"TMT\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Australian Dollar\",\n" +
                "    \"Dcode\": \"AUD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Uganda Shilling\",\n" +
                "    \"Dcode\": \"UGX\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Hryvnia\",\n" +
                "    \"Dcode\": \"UAH\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"UAE Dirham\",\n" +
                "    \"Dcode\": \"AED\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Pound Sterling\",\n" +
                "    \"Dcode\": \"GBP\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar (Next day)\",\n" +
                "    \"Dcode\": \"USN\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Peso Uruguayo\",\n" +
                "    \"Dcode\": \"UYU\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Uruguay Peso en Unidades Indexadas (UI)\",\n" +
                "    \"Dcode\": \"UYI\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Unidad Previsional\",\n" +
                "    \"Dcode\": \"UYW\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Uzbekistan Sum\",\n" +
                "    \"Dcode\": \"UZS\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Vatu\",\n" +
                "    \"Dcode\": \"VUV\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Bolívar Soberano\",\n" +
                "    \"Dcode\": \"VES\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Dong\",\n" +
                "    \"Dcode\": \"VND\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"US Dollar\",\n" +
                "    \"Dcode\": \"USD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"CFP Franc\",\n" +
                "    \"Dcode\": \"XPF\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Moroccan Dirham\",\n" +
                "    \"Dcode\": \"MAD\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Yemeni Rial\",\n" +
                "    \"Dcode\": \"YER\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Zambian Kwacha\",\n" +
                "    \"Dcode\": \"ZMW\"\n" +
                "  },\n" +
                "  {\n" +
                "    \"Dname\": \"Zimbabwe Dollar\",\n" +
                "    \"Dcode\": \"ZWL\"\n" +
                "  }\n" +
                "]";

        try {

            JSONArray jsonArray = new JSONArray(dataVal);
            if (jsonArray != null && jsonArray.length() > 0) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    stringStringMap.put(jsonObject.optString("Dcode").trim(), jsonObject.optString("Dname").trim());
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return stringStringMap;
    }

    public static ArrayList<RatesData> getInitialValue() {
        try {
            Map<String, String> countryDollorData = new HashMap<>();
            countryDollorData = Constans.getCountryDollor();
            JSONObject obj = new JSONObject(inData);
            Constans.baseName = obj.optString("base");
            Constans.baseDollorName = "Euro";
            JSONObject rates = obj.getJSONObject("rates");
            return getJsonObjectValue(rates, countryDollorData);
        } catch (Exception ex) {

        }
        return null;
    }

    public static ArrayList<RatesData> getJsonObjectValue(JSONObject jsonObj, Map<String, String> countryDollorData) {
        ArrayList<RatesData> ratesData = new ArrayList<>();


        try {
            /* Iterator all value and put on model*/
            Iterator<String> iterateValue = jsonObj.keys();

            while (iterateValue.hasNext()) {
                String key = iterateValue.next();
                try {
                    Object keyvalue = jsonObj.get(key);
                    RatesData ratesData1 = new RatesData();
                    ratesData1.setDataName(key);
                    ratesData1.setDataValue(Double.parseDouble(keyvalue.toString()));
                    ratesData1.setDollorName(countryDollorData.get(key));
                    ratesData.add(ratesData1);
                    // Log.e(TAG, "key: " + key + " value: " + keyvalue);
                } catch (JSONException e) {
                    // Something went wrong!
                }
            }

        } catch (Exception ex) {

        }
        return ratesData;
    }
}
