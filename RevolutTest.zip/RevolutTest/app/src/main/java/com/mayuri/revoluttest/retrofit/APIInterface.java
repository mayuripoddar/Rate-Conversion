package com.mayuri.revoluttest.retrofit;


import com.mayuri.revoluttest.pojo.Example;
import com.mayuri.revoluttest.pojo.Revolut;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Query;

public interface APIInterface {

    String BASE_URL = "https://revolut.duckdns.org/";


    @GET("latest?")
    Call<Example> getRevolutCurrency(@Header("accept") String acceptType, @Header("content-type") String contentyType,  @Query("base") String masterData

    );


}
