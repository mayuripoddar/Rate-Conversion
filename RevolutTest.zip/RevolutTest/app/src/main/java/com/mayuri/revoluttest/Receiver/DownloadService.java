package com.mayuri.revoluttest.Receiver;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.mayuri.revoluttest.ConnectionConnector.HttpConnector;
import com.mayuri.revoluttest.network.ApiClient;
import com.mayuri.revoluttest.pojo.Example;
import com.mayuri.revoluttest.pojo.Rates;
import com.mayuri.revoluttest.pojo.RatesData;
import com.mayuri.revoluttest.retrofit.APIInterface;
import com.mayuri.revoluttest.retrofit.Constans;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DownloadService extends IntentService {

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;
    JSONObject rates = null;
    private static final String TAG = "CL";

    public DownloadService() {
        super(DownloadService.class.getName());
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        Log.d(TAG, "Service Started!");

        final ResultReceiver receiver = intent.getParcelableExtra("receiver");
        String url = intent.getStringExtra("url");

        Bundle bundle = new Bundle();

        if (!TextUtils.isEmpty(url)) {
            /* Update UI: Download Service is Running */
            receiver.send(STATUS_RUNNING, Bundle.EMPTY);

            Map<String, String> countryDollorData = new HashMap<>();
            countryDollorData = Constans.getCountryDollor();

            while (true) {
                if (Constans.serviceStopStauts) {
                    Log.e(TAG, ":::::::::Stop Next Execution::::::::");
                    break;
                }
                try {
                    Thread.sleep(1 * 1000);
                    ArrayList<RatesData> results = downloadDataFromServer(url + Constans.countryBaseCode, countryDollorData);
                    /* Sending result back to activity */
                    if (null != results && results.size() > 0) {
                        bundle.putSerializable("result", results);
                        receiver.send(STATUS_FINISHED, bundle);
                    }
                } catch (Exception e) {

                    /* Sending error message back to activity */
                    bundle.putString(Intent.EXTRA_TEXT, e.toString());
                    receiver.send(STATUS_ERROR, bundle);
                }
            }
        }
        Log.d(TAG, "Service Stopping!");
        this.stopSelf();
    }

    private ArrayList<RatesData> downloadDataFromServer(String requestUrl, Map<String, String> countryDollorData) throws IOException, DownloadException {


        try {

//            new HttpConnector(requestUrl);
//            String jsonobjStr = HttpConnector.fetchData(getApplicationContext());
//            JSONObject obj = new JSONObject(jsonobjStr);


            APIInterface apiService = ApiClient.getClient().create(APIInterface.class);
            apiService.getRevolutCurrency("application/json", "application/json", Constans.countryBaseCode).enqueue(new Callback<Example>() {
                @Override
                public void onResponse(Call<Example> call, Response<Example> response) {

                    try {

                        try {


                        } catch (Exception ex) {

                        }
                        if (response.body() != null) {
                            System.out.println("SplashActivity.onResponse " + response);
                            // getStringFromRetrofitResponse(response);
                            Rates rates1 = response.body().getRates();
                            Gson gson = new Gson();
                            String json = gson.toJson(rates1);

                            rates = new JSONObject(json);
                            Log.e("EM", ":::::::::::::Print:::::::::" + json);
                        }
                    } catch (Exception ex) {

                    }


                }

                @Override
                public void onFailure(Call<Example> call, Throwable t) {

                    t.printStackTrace();

                }
            });

            // rates = obj.getJSONObject("rates");


        } catch (Exception ex) {

        }


        return getJsonObjectValue(rates, countryDollorData);


    }

//    public static String getStringFromRetrofitResponse(Response<Example> response) {
//        //Try to get response body
//        BufferedReader reader = null;
//        StringBuilder sb = new StringBuilder();
//        try {
//
//            reader = new BufferedReader(new InputStreamReader(response.body().getRates()));
//
//            String line;
//
//            try {
//                while ((line = reader.readLine()) != null) {
//                    sb.append(line);
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        return sb.toString();
//
//    }


    public static ArrayList<RatesData> getJsonObjectValue(JSONObject jsonObj, Map<String, String> countryDollorData) {
        ArrayList<RatesData> ratesData = new ArrayList<>();


        try {
            /* Iterator all value and put on model*/
            Iterator<String> iterateValue = jsonObj.keys();

            while (iterateValue.hasNext()) {
                String key = iterateValue.next();
                try {
                    Object keyvalue = jsonObj.get(key);
                    RatesData ratesData1 = new RatesData();
                    ratesData1.setDataName(key);
                    ratesData1.setDataValue(Double.parseDouble(keyvalue.toString()));
                    ratesData1.setDollorName(countryDollorData.get(key));
                    ratesData.add(ratesData1);
                    // Log.e(TAG, "key: " + key + " value: " + keyvalue);
                } catch (JSONException e) {
                    // Something went wrong!
                }
            }

        } catch (Exception ex) {

        }
        return ratesData;
    }


    public class DownloadException extends Exception {

        public DownloadException(String message) {
            super(message);
        }

        public DownloadException(String message, Throwable cause) {
            super(message, cause);
        }
    }


}