/**
 * @author NA
 * @since 07-12-2019
 * This class used to Handle Click position
 */
package com.mayuri.revoluttest.Listeners;


import com.mayuri.revoluttest.pojo.RatesData;

public interface OnPositionClickListener {
    void onPostionClick(RatesData ratesDataSingleValue);
}
