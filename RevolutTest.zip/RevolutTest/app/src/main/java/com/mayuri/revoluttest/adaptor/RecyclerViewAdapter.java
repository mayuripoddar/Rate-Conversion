package com.mayuri.revoluttest.adaptor;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mayuri.revoluttest.R;
import com.mayuri.revoluttest.pojo.RatesData;
import com.mayuri.revoluttest.pojo.Revolut;
import com.mayuri.revoluttest.retrofit.Constans;
import com.mayuri.revoluttest.ui.MainActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    private Context mContext;
    Map<String, RatesData> hashMapRateData;
    private ArrayList<RatesData> ratesData;
    private double dollarValue;
    private MainActivity mainActivity;
    private RecyclerViewAdapter.ClickListener clickListener;


    @Inject
    public RecyclerViewAdapter(ClickListener clickListener) {
        this.clickListener = clickListener;
        hashMapRateData = new HashMap<>();
    }

    public interface ClickListener {
        void launchIntent(String RepoName);
    }

//    public void setData(RatesData ratesData) {
//        this.ratesData.add(ratesData);
//        notifyDataSetChanged();
//    }

    public void setData(Map<String, RatesData> hashMapRateData, double dollarValue, Context mContext, MainActivity mainActivity) {
        this.hashMapRateData = hashMapRateData;
        this.dollarValue = dollarValue;
        this.mContext = mContext;
        this.mainActivity = mainActivity;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.currencies_row, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        final RatesData ratesDataChild = (RatesData) hashMapRateData.values().toArray()[position];
        // final RatesData ratesDataChild = hashMapRateData.get(position);
        try {

            if (dollarValue == 0) {
                dollarValue = 1;
            }


            holder.topLayout.setVisibility(View.VISIBLE);
            holder.currValue.setText(String.format("%.2f", (ratesDataChild.getDataValue() * dollarValue)));
            holder.currCountryName.setText(ratesDataChild.getDataName());
            holder.currIndicator.setText(ratesDataChild.getDollorName());
            int rIds = Constans.getResourceIds(ratesDataChild.getDataName().toLowerCase(), mContext);
            if (rIds != 0 && rIds > 0) {
                Picasso.with(mContext).load(rIds).placeholder(R.drawable.ic_circle).into(holder.currImage);
            }
            holder.topLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ratesDataChild.setDataValue(ratesDataChild.getDataValue() * dollarValue);
                    mainActivity.onPostionClick(ratesDataChild);
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public int getItemCount() {
        if (hashMapRateData != null && hashMapRateData.size() > 0) {
            return hashMapRateData.size() > 0 ? hashMapRateData.size() : 0;
        } else {
            return 0;
        }
    }

    public void setValues(Map<String, RatesData> hashMapRateData, double dollarValue) {
        this.hashMapRateData = hashMapRateData;
        this.dollarValue = dollarValue;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView currValue, currCountryName, currIndicator;
        ImageView currImage;
        LinearLayout topLayout;


        public MyViewHolder(View view) {
            super(view);
            currValue = view.findViewById(R.id.currValue);
            currCountryName = view.findViewById(R.id.currCountryName);
            currIndicator = view.findViewById(R.id.currIndicator);
            currImage = view.findViewById(R.id.currImage);
            topLayout = view.findViewById(R.id.topLayout);


        }

    }

}
