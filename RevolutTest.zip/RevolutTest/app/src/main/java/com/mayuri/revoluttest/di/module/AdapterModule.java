package com.mayuri.revoluttest.di.module;



import com.mayuri.revoluttest.adaptor.RecyclerViewAdapter;
import com.mayuri.revoluttest.di.scope.ActivityScope;
import com.mayuri.revoluttest.ui.MainActivity;

import dagger.Module;
import dagger.Provides;

@Module(includes = {MainActivityContextModule.class})
public class AdapterModule {

    @Provides
    @ActivityScope
    public RecyclerViewAdapter getStarWarsPeopleLIst(RecyclerViewAdapter.ClickListener clickListener) {
        return new RecyclerViewAdapter(clickListener);
    }

    @Provides
    @ActivityScope
    public RecyclerViewAdapter.ClickListener getClickListener(MainActivity mainActivity) {
        return (RecyclerViewAdapter.ClickListener) mainActivity;
    }
}
